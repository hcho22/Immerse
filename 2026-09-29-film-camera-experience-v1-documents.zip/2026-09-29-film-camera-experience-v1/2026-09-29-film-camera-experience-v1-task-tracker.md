# Film Camera Experience — V1 Task Tracker

**Date:** October 7, 2026 (original baseline September 29, 2026; versions 1.1 to 1.5 were September 30, 2026; version 2.0 was October 6, 2026) · **Version:** 2.1 · **Platform:** iOS 26, iPhone only\
**Companion:** [Detailed PRD, version 2.1](2026-10-06-film-camera-experience-v1-prd-version-2.0.md) (version 1.5 is kept unchanged in [its own file](2026-09-29-film-camera-experience-v1-prd.md))  
**Status:** Planning baseline. Native implementation tasks are not complete.\
**Scope:** v1 is personal Photo and Movie Films only, as an on-phone iOS 26 iPhone app with no server, Accounts, sign-in or analytics. All Group tasks and all Account-only tasks are deferred to v2 and listed, with their IDs unchanged, under "Deferred to v2" below.

## How to use this tracker

This is the canonical checkbox list for the dated PRD. Every functional area has stable task IDs; do not renumber IDs when adding work. `[ ]` means not verified complete, not necessarily not started. Change to `[x]` only after implementing and validating the stated behavior. Add owner, status, evidence, and completion date underneath an item as work proceeds. No owners or delivery dates are assigned yet.

Suggested annotation: `Owner: … | Status: in progress / blocked / done | Evidence: … | Completed: YYYY-MM-DD`. State any unresolved prerequisite rather than checking a task off because a mockup demonstrates it. `DEC` items resolve open choices; `ARC` items design implementation; other groups implement or verify the recorded product behavior. All are needed for the corresponding scoped function unless the product owner explicitly revises scope.

**Task counts (version 2.0).** The tracker contains 252 items: five completed discovery/prototype items, four DEC items decided (DEC-09 and DEC-15 to DEC-17 on 2026-09-30, checked), 135 unchecked v1 tasks (implementation, decision, architecture, and verification), and 108 unchecked tasks deferred to v2 with Groups and Accounts. Since 2026-10-13 DEC-11 is also decided and checked and CAP-15 was added, so the tracker contains 253 items, five DEC items are checked and 135 v1 tasks are unchecked; no existing ID changed. Every ID from version 1.1 is unchanged (227); version 1.2 added six (DEC-15, DEC-16, DEC-17, STO-11, TRI-11, QA-15) and moved 14 Account-only tasks to v2, version 1.3 added five early-check tasks (ARC-08 to ARC-12), version 1.4 added none, version 1.5 changed no IDs, and version 2.0 added fourteen (CAM-13 to CAM-17, SET-09, CAP-11 to CAP-14, DEV-11, DRK-09, DRK-10, QA-16) and rewrote the text of twelve existing tasks without changing an ID, with the earlier wording preserved in the table at the end of the Deferred to v2 section. Deferred tasks are not part of v1 acceptance and their checkboxes must not be read as v1 progress. Where a v1 task originally mixed personal and Group work, or needed an Account or server, it keeps its ID with that clause removed or rewritten; the removed wording is preserved in the tables at the end of the Deferred to v2 section.

Each task inherits the acceptance criteria and privacy/reveal constraints of its referenced PRD section. For example, completing a Photos export task requires permission and failure behavior, not just a visible button. The final QA section supplies cross-feature verification, not a replacement for task-level checks.

## Completed discovery — not production implementation

- [x] DSC-01 — Capture the product vocabulary and detailed behavior in CONTEXT.md. Evidence: included source snapshot.
- [x] DSC-02 — Record eleven product/architecture decisions. Evidence: included original ADRs and compilation.
- [x] DSC-03 — Build a throwaway browser study comparing Film Journal, Camera Case, and Roll Ledger. Evidence: prototype notes and existing workspace prototype.
- [x] DSC-04 — Select A — Film Journal as the native design basis on 2026-09-29. Evidence: user selection and prototype notes.
- [x] DSC-05 — Perform the browser interaction/layout checks documented in prototype notes. This does not validate native capture, backend security, or billing.

## DEC — Open decisions

Dependency: resolve relevant choices before the affected implementation is accepted. See PRD section 15.

- [ ] DEC-01 — Select final brand/product name and final user-facing terminology/copy.
- [ ] DEC-02 — Set monthly/yearly pricing and specify purchase restoration, offers, refunds/revocations, and entitlement edge handling without changing existing-Film access promises. Timing (captain decision 2026-09-30): decide after testing willingness to pay with TestFlight testers and before billing work starts in M2; nothing in M0-M1 depends on the price.
- [ ] DEC-03 — Choose the native application stack. Settled 2026-09-30: minimum iOS 26 and iPhone only; v1 has no backend or authentication provider.
- [ ] DEC-04 - Approve each Camera's rendering, output resolution/codec/frame-rate/audio specifications and medium-specific controls. Partly decided 2026-10-05 and 2026-10-06 (captain, PRD version 2.0): each Camera's Format Reference, picture shape, look, imperfections and frame rate (Super 8 18 fps, 16mm 24 fps) are set in PRD section 6. Still open: exact tone, contrast and grain values for each Camera and Film Stock, the Instant's contrast and print-to-print variation (they wait on a study of preserved 1970s prints), toning control values, and export codecs/resolution/audio guarantees. Captain decision 2026-10-06: each look is checked against its Format Reference through side-by-side review boards built from public or licensed reference imagery, and the captain approves each Camera (QA-16). Slice 4 (2026-10-09 and 2026-10-10): each Camera's and Film Stock's look is implemented as treatment version 3 (`FilmLook.swift`) and shown on those boards. Captain decisions 2026-10-10: the 1970s Instant develops with the faded look he chose on its board ("faded", then "approved"; ADR 0016, an exception to ADR 0013), which is its current look and current contrast, while its contrast and its print-to-print variation both stay provisional until the study of preserved 1970s prints; the 1960s Super 8 Home Movie develops muted with a glow ("muted with a glow"; ADR 0016); the 1990s Disposable stays fresh ("fresh"); and, on 2026-10-11, the 16mm Cinema's color Film Stock has its black point lifted to about 4 percent at his repeated request (ADR 0016). Captain decision 2026-10-12: that Film Stock develops with the look in the files he sent ("please apply the attached for immerse - 16mm camera kodak vision3 250d"), which replaces the values tuned on the board; shown it there, he asked for "the black up to 4 percent" and chose the way to it that opens the shadows as well ("lets go with C"): a shorter print density range, the one constant that is his later word and not his file's (ADR 0016; `Probes/FilmLookCalibration`). Captain decision 2026-10-12: the 6×6 Medium Format's color Film Stock develops with the look in the files he sent for it ("please apply attached files to immerse 6x6 portra 400 film"): his generator's "scan" look, read from his own table, with his spec's lens vignette and very fine grain, in place of the values tuned on the board (ADR 0016); nothing his spec describes beyond the look is built, by his decision of 2026-10-12 ("keep it as the look only"). Captain approvals 2026-10-12, on their boards: the 16mm Cinema ("lets go with C" for color, "black and white looks good") and the 6×6 Medium Format ("everything looks good", with the color look as his files have it). With the 1990s Disposable, the 1970s Instant and the 1960s Super 8 Home Movie approved on 2026-10-10, every Camera's look now has his approval; of the values listed above as still open, the tone, contrast and grain of each Camera and Film Stock are closed, all but the Instant's contrast, and the Instant's contrast and print-to-print variation (both provisional until the study of preserved 1970s prints, with the approved faded look as the current one), toning control values, and export codecs, resolution and audio guarantees stay open. Partly decided 2026-10-13 (captain): export sizes and formats. Photos are JPEG, the Disposable at no more than 12,000,000 pixels in its borderless 3:2 shape and the 6×6 at 3072 × 3072; Movies are H.264 in a `.mov` at 1920 × 1440, or 1440 × 1920 for a portrait Movie, the Super 8 at 18 frames a second and the 16mm at 24, silent. The app writes these and tests read them back from exported files (`Evidence/NativeApp/darkroom-export-decisions-060.md`). Asked the same day about the Instant's size and about color tags on Movies, he said: "instant export size: A,  leave Movies as they are". An Instant print is saved exactly as it was developed, 2282 × 2774, the 2048 × 2048 picture on its white card, with no resampling, and Movies keep no color tags; whether tagging would change anything on a phone is looked at during the manual iPhone test. Decided 2026-10-13 (captain), on review boards of their own: the Instant's contrast is the one a study of preserved 1970s prints supports ("B", treatment version 4, ADR 0016; `Evidence/NativeApp/instant-study-and-toning-061.md`), and its print-to-print variation stays as it was (B means "contrast only"); each chemical toner's slider runs from the untoned print to the strength shown as 1.00 ("sepia - untoned to 1. selenium - untoned to 1"; `ToningLook.swift`). That closes the two items still open after the export decisions. The box stays unchecked while AGENTS.md still holds the Movie capture's native 4:3 format size provisional under DEC-04.
- [ ] DEC-05 — Select and clear production sample media and export-licensed built-in instrumental soundtracks. Decided 2026-10-13 (captain): only material he owns or has written rights to; the samples are his own shots, one for each Camera and Film Stock, so the shipped catalog stays empty until he supplies them; no built-in soundtrack until a license allows it inside exported Movies. Still open: the seven shots themselves, so this stays unchecked.
- [x] DEC-09 — Define empty-Film early Development and presentation when every Movie clip is removed. Decided 2026-09-30: disable early Development until a Film has a saved capture; offer Delete Film for empty Films; after the last Movie clip is discarded retain an empty Film with numbered discarded placeholders and no playback or export. Status: done | Evidence: captain decision relayed in Firstmate v1 implementation brief; PRD section 15 | Completed: 2026-09-30
- [x] DEC-11 - Specify analog Darkroom ranges/crop boundaries, Instant original-export choice timing, and personal soundtrack reselection behavior. Partly decided (PRD version 2.0 and the captain, 2026-10-06): Instant prints have no crop; contrast grades 0 to 5 apply to every Photo Film, color and Instant included, and chemical toning applies only to black-and-white Films, which in v1 are 6×6 Medium Format Films on the black-and-white Film Stock (captain, 2026-10-07, reversing the 2026-10-06 contrast half; PRD 2.1 FR-07 says so). Still open: control ranges, Instant original-export timing, soundtrack reselection. Decided 2026-10-13 (captain: "looks good. can we change the exposure, dodge and burn to plus and minus 3 stops?"): print exposure -3.0 to +3.0 stops in 0.1-stop steps; Dodge and Burn -3.0 to +3.0 stops; color filtration cyan, magenta and yellow -30 to +30 in whole units; contrast grades 0 to 5; crop per photo, with the 6×6 staying square and no crop for an Instant print; Reset returns the developed original exactly; the Instant asks about keeping the original after each print; a Movie's soundtrack can be changed later without developing again. Status: done | Evidence: the 2026-10-13 addendum to the [open-decision recommendations](2026-09-29-film-camera-experience-v1-open-decision-recommendations.md) and `Evidence/NativeApp/darkroom-export-decisions-060.md` | Completed: 2026-10-13. The toning strength for black-and-white 6×6 prints was decided the same day on its own board, under DEC-04.
- [ ] DEC-12 - Define low-storage behavior, supported-device/accessibility matrix, media durability, and measurable performance/reliability budgets. Decided 2026-10-13 (captain), as targets not yet measured: the oldest supported phone is the iPhone 11; a photo saves in under 1 second; a 27-photo roll develops in under 45 seconds; a full Super 8 Movie assembles in under 90 seconds; the app warns below 2 GB free. No iPhone 11 is available, so they are measured when one is, the 16mm Cinema's 167-second Movie among them (ARC-08). The warning below 2 GB free is built (CAP-15), where and how the captain decided on 2026-10-13, and no iPhone has run it yet. The other rows of the recommendation (a memory ceiling, the accessibility matrix, when the backup disclosure appears) were not put to him and stay recommendations, so this stays unchecked.
- [ ] DEC-13 — Define support escalation, privacy disclosures, and platform/launch review requirements. Approach decided 2026-10-13 (captain): the privacy text says there is no server, account, analytics or microphone; the delete text says exports stay and old backups can bring media back; support never promises recovery without a backup. Still open: the wording itself, written closer to launch, so this stays unchecked.
- [ ] DEC-14 — Approve numeric learning targets for the TestFlight and interview plan (PRD section 2.2). Settled 2026-09-30: no analytics SDK or service in v1; no implicit media telemetry. Decided 2026-10-13 (captain): no analytics in the app; he learns from TestFlight interviews, tester feedback and Apple's own reports. The targets themselves were not put to him and are not set, so this stays unchecked.
- [x] DEC-15 — Decide whether starting the Trial Film needs connectivity. Decided 2026-09-30 (option A): it never needs connectivity. Status: done | Evidence: captain decision 2026-09-30; PRD section 15 and FR-21 | Completed: 2026-09-30
- [x] DEC-16 — Decide what a restored iPhone does with an unused Trial Film and with a captured Trial Film. Decided 2026-09-30 (option A for both): a captured Trial Film keeps capturing its remaining capacity, and a started Trial Film with no captures stays usable; either coexists with the destination iPhone's own entitlement without consuming or blocking it. Status: done | Evidence: captain decision 2026-09-30; PRD section 15 and FR-21 | Completed: 2026-09-30
- [x] DEC-17 — Decide how privacy removals (Discard, Delete Film, Movie reassembly) interact with a restore from an older device backup. Decided 2026-09-30 (option A): accept that an older backup can bring back removed app data, including discarded media or a deleted whole Film, disclose it in the privacy copy and Delete Film confirmation, and keep no removal log. Status: done | Evidence: captain decision 2026-09-30; PRD section 15, FR-16 and FR-18 | Completed: 2026-09-30

## ARC — Foundation and architecture

Dependency: relevant DEC items. PRD sections 11–13. Proposed engineering work, not a preselected vendor architecture.
ARC-08 to ARC-12 are the early checks from the [architecture baseline](2026-09-29-film-camera-experience-v1-architecture.md) (added in version 1.3); the sixth early check is TRI-11. They settle ranked risks before the work that depends on them and are scheduled in M1 and M2, not M0.

- [ ] ARC-01 — Establish native application build, local development setup, supported devices (iPhone, iOS 26), and test environments.
- [ ] ARC-02 — Design separate Film, capture, reveal, entitlement, archive, and deletion state models with enforceable invariants.
- [ ] ARC-03 — Design local media persistence, atomic save/recovery boundaries, device-backup contents, Camera versioning, and developed-master integrity checks.
- [ ] ARC-05 — Design StoreKit subscription validation and the per-iPhone Trial record (Keychain), with Trial consumption recoverable around app termination.
- [ ] ARC-06 — Design private source/master/clip storage, privacy tombstones, deletion jobs, and stale-version retirement.
- [ ] ARC-07 — Document approved technical decisions and verification strategy without treating the disposable browser prototype as production architecture.
- [ ] ARC-08 - Early check, M1 for photos and M2 for Movies: time personal Photo and Movie Development on an iPhone 11 running iOS 26, foreground only, including an interrupted and resumed run; report the result before the supported-device floor (DEC-12) is set. Source: architecture baseline 9.1, check S1.
- [ ] ARC-09 - Early check, M2 before billing work: read StoreKit entitlements offline after one online sync, and restore a purchase with only an Apple ID; report the result before offline entitlement checks are relied on. Source: architecture baseline 9.1, check S8.
- [ ] ARC-10 - Early check, M2: assemble, discard, rebuild and export a Movie on hardware (borders for opposite orientation, optional soundtrack, HEVC, HDR, orientation) and confirm a rebuilt Movie keeps every surviving Developed Clip unchanged. Source: architecture baseline 9.1, check S11.
- [ ] ARC-11 - Early check, M2: exercise the Trial on the device by terminating the app around the first save (including between the durable capture commit and the Keychain write, followed by delete and reinstall, which measures the open Trial first-save window in architecture baseline 8.1 without deciding it), deleting a zero-save Trial Film, and restoring a Trial Film onto a second iPhone that has its own unused entitlement; report before Trial work is accepted. Source: architecture baseline 9.1, check S12.
- [ ] ARC-12 - Early check, M2 and repeated as QA-15 in M5: back up a phone with large Films, restore onto a second iPhone, verify sealed and developed states, Darkroom edits and Movie assemblies, then restore an older backup and record what reappears and how large the backup is. Source: architecture baseline 9.1, check S13.

## UX — Film Journal library and organization

Dependency: ARC-01–ARC-03. PRD FR-02.

- [ ] UX-01 — Implement A — Film Journal's memory-first native library; omit B/C layouts and review-console controls from production.
- [ ] UX-02 — Make Start a Film primary; route Darkroom only from eligible developed photos.
- [ ] UX-03 — Present unfinished, complete, developing, and developed states without sealed/inaccessible thumbnails.
- [ ] UX-04 — Persist multiple unfinished personal Films and resume any without revealing other Films.
- [ ] UX-05 — Suggest personal Camera-and-roll-number titles; allow optional custom names and post-load/post-Development renaming.
- [ ] UX-07 — Derive Capture Date Range from first/last captures rather than scheduled event dates.
- [ ] UX-08 — Implement explicit per-user Archive, archived list, and restore without deletion or capacity changes.

## CAM — Camera packages and samples

Dependency: DEC-04–DEC-05, ARC-02–ARC-03. PRD FR-01.

- [ ] CAM-01 — Model immutable complete Camera packages: medium, framing, behavior, capacity, audio, treatment, and Reveal Rule.
- [ ] CAM-02 — Implement 1990s Disposable: 27 exposures, fixed focus, supported optional flash, roll Development.
- [ ] CAM-03 — Implement 1970s Instant: 10 exposures, per-exposure Development, personal-only eligibility.
- [ ] CAM-05 - Implement the 6×6 Medium Format (no decade, PRD 2.0): 12 square exposures, waist-level presentation, deliberate focus/exposure, optical focus only.
- [ ] CAM-06 - Implement 1960s Super 8 Home Movie: 200-second fixed capacity at 18 frames per second, fine grain, brightness flicker, an unsteady frame and dust and hair in the gate, silent capture.
- [ ] CAM-07 - Implement the 16mm Cinema (no decade, PRD 2.0): 167-second (2:47) fixed capacity at 24 frames per second, visible grain, highlight halation, minor jitter and weave, no per-clip limit, silent capture.
- [ ] CAM-10 - Create curated sample media and plain-language capacity/control/reveal/audio descriptions for every Camera and, on the 6×6 Medium Format and the 16mm Cinema, for each Film Stock.
- [ ] CAM-11 - Use descriptive historical-format names; exclude digital formats, any stock selection other than the Film Stock choice at Load Film on the 6×6 Medium Format and the 16mm Cinema (ADR 0014), and unapproved manufacturer branding; Format Reference names never reach the product (ADR 0015).
- [ ] CAM-12 - Validate format-distinct developed treatments, judged against each Camera's Format Reference with no aging added (ADRs 0013 and 0015), and bounded authentic imperfections without synthetic catastrophic capture destruction. Since 2026-10-10 the 1970s Instant's faded look and the 1960s Super 8 Home Movie's muted look with a glow are the captain's exceptions (ADR 0016). Since 2026-10-12 the color Film Stocks of the 16mm Cinema and the 6×6 Medium Format develop with the looks in the captain's own files (ADR 0016).

- [ ] CAM-13 - (PRD 2.0 slice 1) Rename the 6×6 Medium Format and the 16mm Cinema without a decade in the catalog, Load Film, capture and Film detail, and set the 16mm Cinema capacity to 2:47 (167 seconds); Films already loaded keep the package they locked.
- [ ] CAM-14 - (PRD 2.0 slice 1) Make the white card part of every developed Instant print: the developed master, the Journal and Darkroom views and Save Developed to Photos.
- [ ] CAM-15 - (PRD 2.0 slice 1) Update catalog, Load Film and Camera sample copy for the new per-Camera looks and controls, including the explanation that the 6×6 Medium Format's viewfinder shows the scene reversed left to right.
- [ ] CAM-16 - (PRD 2.0 slice 3) Model Film Stock in the domain and persistence: record it on the Film at Load Film where the Camera offers one, fix it for that Film, keep earlier Films readable as having no Film Stock, and give the 6×6 Medium Format and 16mm Cinema packages one treatment per Film Stock (ADR 0014).
- [ ] CAM-17 - (PRD 2.0 slice 4) Implement the per-Camera developed looks and imperfections of PRD sections 6.1 to 6.3 as a new treatment version that leaves unfinished Films renderable, with fresh results (ADR 0013) and no manufacturer or film name in any product string (ADR 0015). Dependency: the open part of DEC-04 and QA-16. Since 2026-10-10 the 1970s Instant's faded look and the 1960s Super 8 Home Movie's muted look with a glow are the captain's exceptions (ADR 0016). Since 2026-10-12 the color Film Stocks of the 16mm Cinema and the 6×6 Medium Format develop with the looks in the captain's own files (ADR 0016).

Retired v1 task IDs: CAM-04, CAM-08, and CAM-09. See the PRD's v1 scope and Camera catalog.

## SET — New Film and Load Film

Dependency: UX, CAM, entitlement interfaces. PRD FR-03.

- [ ] SET-01 — Start with Camera selection.
- [ ] SET-03 — Permit curated Camera Preview before subscribing or starting the Trial with no live filter feed or user capture access.
- [ ] SET-04 — Ensure browsing/canceling previews consumes no Trial and creates no active Film.
- [ ] SET-05 - Add explicit Load Film confirmation showing Camera, capacity, and Reveal Rule and, on the 6×6 Medium Format and the 16mm Cinema, the Film Stock.
- [ ] SET-06 - Lock Camera package and, where the Camera offers one, Film Stock permanently at Load while preserving adjustable supported focus/flash/exposure controls.
- [ ] SET-08 — Add Movie Orientation setup and lock at the agreed boundary.
- [ ] SET-09 - (PRD 2.0 slice 3) Add the Film Stock choice, color or black-and-white, to Load Film for the 6×6 Medium Format and the 16mm Cinema, confirmed and fixed by Load Film; no choice on any other Camera.

## CAP — Native capture and viewfinder

Dependency: CAM, SET, ARC-03. PRD FR-04.

- [ ] CAP-01 — Build native in-app Photo capture with durable-save confirmation and correct exposure accounting.
- [ ] CAP-02 — Reject/import no existing media from Photos, Files, or other apps into a Film.
- [ ] CAP-03 - Render Camera-authentic framing/capture cues without previewing the developed result: grain, color variation, halation, flicker, frame unsteadiness, dust, or edge softening.
- [ ] CAP-04 — Support front/rear lenses across personal Photo and Movie capture without replacing the selected Camera.
- [ ] CAP-05 — Mirror front viewfinders but produce unmirrored saved/developed photo and movie results.
- [ ] CAP-06 — Permit lens switching only between exposures/clips; block switches during capture/recording.
- [ ] CAP-07 — Expose only Camera-authentic, hardware-supported controls and explain unavailable capabilities briefly.
- [ ] CAP-08 — Support entitled personal offline capture with no server dependency; Trial start needs no connectivity (DEC-15).
- [ ] CAP-09 — Handle camera permission, save failures, storage interruptions, and relaunch without false successful-save/capacity consumption.
- [ ] CAP-10 — Keep saved sealed media private: no review, individual delete, thumbnails, or automatic Photos export before reveal.
- [ ] CAP-11 - (PRD 2.0 slice 2) 1990s Disposable: a borderless 3:2 viewfinder and developed picture with no date stamp.
- [ ] CAP-12 - (PRD 2.0 slice 2) 1990s Disposable: fixed exposure, so scene brightness and flash decide how an exposure develops, and a live low-light cue advising flash that never previews the developed result. Needs an early check that a fixed exposure is achievable on the supported iPhones.
- [ ] CAP-13 - (PRD 2.0 slice 2) 1960s Super 8 Home Movie: a fixed-focus lens and automatic exposure.
- [ ] CAP-14 - (PRD 2.0 slice 2) 6×6 Medium Format: a rear viewfinder that shows the scene reversed left to right, developed exposures that are not reversed, a front viewfinder that keeps its mirrored behavior, and optical-only focus with no synthesized background blur.
- [ ] CAP-15 - Warn when the iPhone has less than 2 GB free. Approved by the captain on 2026-10-13 as a target (DEC-12: "The app warns below 2 GB free"). The same day he approved where and how ("low storage - approve"): above Load Film, and above Open Camera or Develop Film on the Film screen, in two sentences that stop nothing. Status: built and tested on simulators; a nearly full iPhone has not run it, so this stays unchecked | Evidence: `Evidence/NativeApp/low-storage-warning-062.md`

## MOV — Personal Movie mechanics

Dependency: CAM, CAP, SET, relevant DEC-04/DEC-11 decisions. PRD FR-05.

- [ ] MOV-01 — Record start/stop clips and debit only successfully saved active recording duration.
- [ ] MOV-02 — Exclude pause/idle time and prevent footage beyond the Camera's authorized budget.
- [ ] MOV-03 — Preserve clip chronology/start-stop cuts and produce one Developed Movie; no timeline editing controls.
- [ ] MOV-04 — Support portrait/landscape clips, locking each clip's orientation at recording start.
- [ ] MOV-05 — Lock final Movie Orientation before recording and fit opposite clips with borders using native frame proportions.
- [ ] MOV-06 — End clips on call, lock, or background; salvage valid footage and require explicit next recording rather than auto-resume.
- [ ] MOV-07 — Make both v1 Movie Cameras silent without microphone permission requests or capture.
- [ ] MOV-09 — Offer silence or one licensed built-in instrumental for silent developed Movies; prohibit imported music/voice-over.
- [ ] MOV-10 — Preserve Developed Clips separately from sources and the assembled Movie for privacy-safe future reassembly.
- [ ] MOV-11 — Validate chronological playback, audio, orientation, borders, and full-Movie export against approved output specifications.

Retired v1 task ID: MOV-08. See the PRD's v1 scope and Camera catalog.

## DEV — Completion and one-time Development

Dependency: CAP, MOV where relevant, durable storage. PRD FR-06.

- [ ] DEV-01 — Complete personal rolls/movies at capacity without automatic Development.
- [ ] DEV-02 — Implement Rewind & Develop Early with exact remaining-exposure warning and irreversible waste.
- [ ] DEV-03 — Implement Stop & Develop Early with exact remaining-time warning and irreversible waste.
- [ ] DEV-04 — Implement explicit Development and a brief reveal ritual without artificial multi-hour delay.
- [ ] DEV-05 — Develop Instant exposures individually, including the final pack frame; do not reseal earlier prints.
- [ ] DEV-06 — Assign and persist a one-time treatment per capture with no reroll/redevelopment action.
- [ ] DEV-07 — Resume interrupted Development after relaunch with saved captures and assigned treatment intact.
- [ ] DEV-08 — Hide unfinished results and prevent recovery from restoring discarded/deleted content.
- [ ] DEV-10 — Verify developed masters/clips before allowing source cleanup; implement the DEC-09 empty-Film policy.
- [ ] DEV-11 - (PRD 2.0 slice 3) Develop black-and-white Films: the 6×6 Medium Format black-and-white photo path, which enables the Darkroom's black-and-white controls, and the 16mm Cinema black-and-white Movie path, both fixed by the Film Stock chosen at Load Film.

## DRK — Analog photo Darkroom

Dependency: DEV, DEC-04/DEC-11. PRD FR-07.

- [ ] DRK-01 — Implement independent, reversible per-exposure recipes over preserved developed masters.
- [ ] DRK-02 - Implement print exposure and contrast grades 0 to 5 on every Photo Film, color and black-and-white, Instant prints included (captain decision 2026-10-07; each Camera's own developed contrast stays set by its Developed Treatment).
- [ ] DRK-03 - Implement eligible color filtration/balance and, for black-and-white Films only, chemical toning, without saturation (contrast grades are DRK-02 and apply to every Photo Film).
- [ ] DRK-04 - Implement agreed analog-print crop behavior without changing the underlying Camera package; Instant prints have no crop.
- [ ] DRK-05 — Implement reversible local Dodge/Burn masks within analog exposure-adjustment limits.
- [ ] DRK-06 — Add Reset to Original and verify exact recovery of the original developed appearance.
- [ ] DRK-08 — Exclude Movie Darkroom, treatment swaps, AI/content manipulation, and saturation controls.
- [ ] DRK-09 - (PRD 2.0 slice 1) Offer no crop control for an Instant print and reject an Instant recipe that carries a crop, keeping the square picture and its white card whole.
- [ ] DRK-10 - (PRD 2.0 slice 1) Keep contrast grades 0 to 5 on every Photo Film, color and Instant included, and offer chemical toning only on black-and-white Films, which in v1 are 6×6 Medium Format Films on the black-and-white Film Stock (captain decisions 2026-10-06 and 2026-10-07; the app already offers grades on every Photo Film, so this task confirms that and gates toning).

## STO — Personal persistence and Photos integration

Dependency: ARC-03, DEV, approved media specifications. PRD FR-08.

- [ ] STO-01 — Persist personal Film metadata, sources, masters, Developed Clips, and edits device-locally across relaunch.
- [ ] STO-02 — Explain that Films live on this iPhone and are included in iOS device backups, that the app has no sync or backup of its own, and that a lost phone without a device backup loses its Films.
- [ ] STO-03 — Store unrevealed sources privately with no pre-reveal write to native Photos.
- [ ] STO-04 — Offer optional Save Developed to Photos for eligible photographs and complete Movies.
- [ ] STO-05 — Offer optional Save Originals to Photos independently of developed export after eligible reveal.
- [ ] STO-06 — Implement Photos permission denial/write failures and success reporting; no false export completion.
- [ ] STO-07 — Remove chosen personal original sources only after successful Photos saving and verified master retention.
- [ ] STO-08 — On declined original export, delete sources only after verified master storage and show the source-cleanup disclosure specified in PRD FR-08.
- [ ] STO-09 — Retain developed masters/clip assets/reversible edits after source cleanup; preserve offline personal viewing.
- [ ] STO-10 — Explain flattened exports are not restorable Films; never automatically delete/archive the Film after export.
- [ ] STO-11 — Include Film data in iOS device backups (no backup exclusion on Films; keep derivable or temporary files out to limit size) so restoring a phone restores its Films, and keep the Trial record out of the restore.

## IDN — Authentication

No v1 tasks. v1 has no Account or sign-in, so IDN-01 and IDN-04 moved to Deferred to v2 in version 1.2.


## PRV — Capture privacy and Discard

Dependency: media deletion/reassembly architecture. PRD FR-16.

- [ ] PRV-01 — Implement permanent Discard of revealed personal captures, preserving numbered placeholders and consumed capacity.
- [ ] PRV-05 — Remove source/master/Developed Clip/app-controlled cache content and retain metadata-only chronology.
- [ ] PRV-06 — Enforce no refunds of exposures/time.
- [ ] PRV-07 — Retire affected Movie versions and rebuild from unchanged surviving clips without repeating Development.
- [ ] PRV-08 — Preserve surviving chronology, final orientation, and selected soundtrack through reassembly; after all clips are removed, apply DEC-09 by retaining numbered discarded placeholders with no playback or export.
- [ ] PRV-10 — Explain permanent app removal and the limits of external exports and device backups; verify no stale viewing/export after accepted privacy action and disclose that restoring an older backup can bring back media discarded after it (DEC-17).

## DEL — Whole personal Film deletion

Dependency: STO, TRI. PRD FR-18.

- [ ] DEL-01 — Add explicit confirmation that personal Photo/Movie Delete Film, sealed or revealed, removes the Film from current app-controlled storage while a pre-deletion iOS backup can bring it back.
- [ ] DEL-02 — Remove personal Film details, all retained media, and edits from current app-controlled storage without revealing sealed content; disclose that external exports remain and restoring an iOS backup made before deletion can bring the whole Film back (DEC-17).
- [ ] DEL-03 — Delete an unused Trial Film (zero saved captures) directly, with no cancellation step and no change to Trial eligibility.
- [ ] DEL-04 — Never restore used Trial eligibility.

## IDD — Account deletion lifecycle

No v1 tasks. v1 has no Account, so there is no Account deletion; all IDD tasks moved to Deferred to v2 in version 1.2. PRD FR-19 is a v2 stub.


## BIL — All-inclusive subscription

Dependency: DEC-02 (resolved before billing work starts in M2), ARC-05. PRD FR-20.

- [ ] BIL-01 — Implement one all-inclusive monthly/yearly subscription using approved pricing and product configuration.
- [ ] BIL-02 — Permit unlimited new entitled personal Films and all Cameras without per-Film charges or tiers.
- [ ] BIL-03 — Support purchase, restoration and all personal use through StoreKit and the Apple ID, with no app Account, sign-in or server.
- [ ] BIL-05 — On expiry block only new Films, retaining existing capture/completion/edit/export rights.
- [ ] BIL-06 — Implement StoreKit purchase restoration, renewal, entitlement checks, and approved refund/revocation behavior.
- [ ] BIL-07 — Provide subscription-management entry and clear distinction between billing cancellation and Film deletion.

## TRI — Per-iPhone device-bound Trial entitlement

Dependency: ARC-05, CAP durability; DEC-15 and DEC-16 (decided) for Trial start without connectivity and restored Trial Films. PRD FR-21. TRI-05 to TRI-08 and TRI-10 moved to Deferred to v2 in version 1.2.

- [ ] TRI-01 — Implement the per-iPhone Photo OR Movie Trial entitlement under [PRD FR-21](2026-10-06-film-camera-experience-v1-prd-version-2.0.md#fr-21--one-complete-trial-film), including its unused-Film replacement rule.
- [ ] TRI-02 — Record the iPhone's Trial entitlement in the Keychain so it survives deleting and reinstalling the app, stays bound to this physical iPhone, and is not restored onto another iPhone; a Trial Film restored from a backup keeps its own capture rights and coexists without consuming or blocking this iPhone's entitlement (DEC-16).
- [ ] TRI-03 — Apply FR-21's first-save consumption rules to this iPhone's device-bound entitlement, including the distinction from restored Film rights.
- [ ] TRI-04 — Write the Trial record atomically around the first successful save so app termination cannot leave a free second Trial; capture and Trial start need no server or connectivity (DEC-15).
- [ ] TRI-09 — Preserve developed Trial access and reject entitlement refunds after used-Film deletion/Discard/abandonment or app reinstall.
- [ ] TRI-11 — Early device check on iOS 26 hardware: confirm the Keychain Trial record survives deleting and reinstalling the app and is absent after restoring a backup onto a different iPhone; note the effect of an OS update and of an erase; report the result before Trial work is built. If the record does not survive, raise a new decision instead of adding a server or Account.

## QA — Cross-feature acceptance and launch readiness

Dependency: relevant implemented slices; test continuously rather than waiting until the end. PRD section 13.

- [ ] QA-01 — Verify all five Camera capacities, genuine control differences, reveal/audio behavior, and immutable Camera selection on real devices.
- [ ] QA-02 — Verify personal full/early completion, exact waste warnings, multiple unfinished Films, Instant final print, and no sealed previews.
- [ ] QA-03 — Verify deterministic Development restart across app termination and no treatment rerolls or media loss.
- [ ] QA-04 — Verify every Darkroom control, per-exposure isolation, reset, and exclusion of prohibited editing.
- [ ] QA-09 — Verify source deletion, failed Photos writes, verified-master gating, and unaffected external exports.
- [ ] QA-11 — Verify Movie stale-version retirement and unchanged surviving clip treatment/audio/order/orientation/soundtrack after removals.
- [ ] QA-12 — Verify subscription expiration, account-free paid use, and both halves of the per-iPhone Trial invariant: this iPhone's device-bound entitlement cannot start another Trial Film after its first successfully saved capture, including after reinstall or an offline first save, while deleting a zero-save Trial Film leaves the entitlement available; a captured or empty Trial Film restored from another iPhone keeps its capture rights, coexists with this iPhone's own Trial Film, and neither consumes nor blocks this iPhone's entitlement.
- [ ] QA-13 — Verify supported devices (iPhone, iOS 26), accessibility, front mirroring/output orientation, mic/camera/Photos denial, low storage, relaunch, export fidelity, and agreed performance budgets.
- [ ] QA-14 — Complete production asset/licensing, disclosures/support, platform review, unresolved-decision review, and evidence-backed release sign-off; do not use prototype checks as native completion evidence.
- [ ] QA-15 — Verify iOS device backup and restore: Films, sealed and developed states and Darkroom edits return on a replacement iPhone while the Trial record does not; restoring an older backup can bring back both media discarded after that backup and an entire Film deleted after it; and the privacy copy and Delete Film confirmation disclose both DEC-17 outcomes.
- [ ] QA-16 - (PRD 2.0 slice 4) Build side-by-side review boards of each Camera's developed output against its Format Reference, using public or licensed reference imagery and covering both Film Stocks where offered; the captain approves each Camera (captain decision 2026-10-06). Boards are specification review, not hardware acceptance.

## PRD 2.0 implementation slices

Captain decision, 2026-10-06: the documents land first, as one docs-only change, and PRD version 2.0 is then implemented in the slices below, in this order.
The manual iPhone test candidate is the build that includes PRD 2.0.
Task IDs stay in their own groups above; this table gives the order only.

| Slice | Work | Tasks |
| --- | --- | --- |
| 1 | Names and capacity, the Instant card and no crop, toning gated to black-and-white Films with contrast kept on every Photo Film, catalog copy | CAM-13, CAM-14, DRK-09, DRK-10, CAM-15 |
| 2 | Capture behavior: Disposable 3:2, fixed exposure and low-light cue, Super 8 fixed focus, 6×6 reversed viewfinder | CAP-11, CAP-12, CAP-13, CAP-14 |
| 3 | Film Stock end to end: model, Load Film choice, black-and-white development | CAM-16, SET-09, DEV-11 |
| 4 | Per-Camera looks against their Format References, as the open DEC-04 values close | CAM-17, QA-16 |

## Captain decisions recorded in version 2.0

These record what the captain said on 2026-10-06 after reading the comparison of PRD version 2.0 with the repository, and the ADR 0015 file he supplied the same day.
The PRD and ADR text is the captain's and is not edited here; where a decision changes how a PRD sentence applies, the decision is recorded in this tracker instead.

| Question | Captain's decision (2026-10-06) | Recorded in |
| --- | --- | --- |
| ADR 0015 was cited by PRD 2.0 and CONTEXT.md but not delivered | Supplied by the captain; it is added to `adr/` and the ADR collection as delivered. | ADR collection, README |
| Contrast control on color Films (PRD FR-07 says contrast grades and chemical toning apply to black-and-white Films; the app offered grades on every Photo Film) | Superseded 2026-10-07 (see the next row). Color Films get no contrast control at all. Contrast grades and chemical toning are black-and-white only, which in v1 means 6×6 Medium Format Films on the black-and-white Film Stock. PRD FR-07's wording is unchanged. | DEC-11, DRK-02, DRK-03, DRK-10 |
| Contrast control on color Films, asked again after the 2026-10-06 decision ("Grades on every Film") | Captain, 2026-10-07: "please update the prd so that the contrast can be adjusted in the darkroom as well." Contrast grades 0 to 5 apply to every Photo Film, color and black-and-white, Instant prints included. Chemical toning stays black-and-white only. PRD 2.1 FR-07 carries it (the PRD was edited at the captain's request, which overrides the note above for this decision). | DEC-11, DRK-02, DRK-03, DRK-10, PRD 2.1 |
| How a look is checked against its Format Reference | Side-by-side review boards built from public or licensed reference imagery, with the captain approving each Camera. | DEC-04, QA-16 |
| Sequencing | Land the documents first as one docs-only change; then implement in the slices above; the manual iPhone test candidate is the build that includes PRD 2.0. | The slices above, Milestone tracking |
| Whether the 1970s Instant develops fresh, as ADR 0013 sets, or faded, asked on its look review board, which showed candidate A (fresh, with his contrast, exposure, warmth and softness notes applied) beside candidate B (the faded look his own notes described) | Captain, 2026-10-10: "faded". The Instant's Developed Treatment is the faded look: lifted, milky blacks, softened whites, low contrast, muted color and age-style tints. It is an exception to ADR 0013 and to PRD section 6.1's "Brilliant, warm, saturated color" for that Camera; every other Camera stays under ADR 0013 unless the captain chooses otherwise on its own board. | ADR 0016 and its reconciliation notes in the ADR collection, DEC-04, CAM-03, CAM-12, CAM-17, QA-16 |
| Whether the 1960s Super 8 Home Movie develops with strong, rich color, as PRD section 6.2 sets, or with the look his notes described, asked on its look review board, which showed candidate A (strong, rich color, with his softness and tint notes applied) beside candidate B (lower contrast, slightly desaturated, with a glow) | Captain, 2026-10-10: "muted with a glow". The Super 8's Developed Treatment has lower contrast, slightly desaturated color, darker shadows, lowered whites, teal in the shadows and warmth in the highlights, a softer picture and a warm reddish-orange glow around bright highlights. It is an exception to ADR 0013 and to PRD section 6.2's "Strong, rich color" for that Camera, and gives it a glow the PRD otherwise gives only to the 16mm Cinema. Scratches and a film-frame border are not added. | ADR 0016 and its reconciliation notes in the ADR collection, DEC-04, CAM-06, CAM-12, CAM-17, QA-16 |
| Whether the 1990s Disposable develops fresh or with the matte, slightly faded look his notes described, asked on its look review board, which showed both | Captain, 2026-10-10: "fresh". The Disposable stays under ADR 0013, with his in-rule notes applied (slightly brighter, bright flash-lit whites, coarser visible grain, a green-cyan cast in the shadows, deeper blues, a feathered dark border). | DEC-04, CAM-02, CAM-17, QA-16 |
| Where the black point of the 16mm Cinema's color Film Stock sits, raised on its look review board: the fresh rule's limit of about 3 percent, or the 4 percent his notes asked for | Captain, 2026-10-10 and again 2026-10-11, after the board said 4 percent passes the fresh rule's limit and would be recorded as his choice: "Raise the black point slightly to about 4% ... to create a soft, grayed-out, lifted-black cinematic effect." The color Film Stock's black point is about 4 percent; nothing else about the 16mm Cinema departs from ADR 0013. Kept on 2026-10-12, at his word, when the look in his own files was applied (next row). | ADR 0016, DEC-04, CAM-07, CAM-17, QA-16 |
| What the 16mm Cinema's color Film Stock develops with, after he replied on its board with a written spec and then sent the files that define the look | Captain, 2026-10-12: "please apply the attached for immerse - 16mm camera kodak vision3 250d". The color Film Stock's look is his generator's "print" look and his reference's per-frame passes, in place of the look tuned on the board. His files put black at about 1.3 percent; shown that on the board the same day, he wrote "the blacks are too strong for color. please tone it down" and then "please bring the black up to 4 percent", and of the two ways to it the board then showed he chose the one that opens the shadows as well ("lets go with C"), so the print's density range is 2.74 where his file has 4.39, the one value that is not his file's. The look is taken from his files and not held to ADR 0013's limits. With "black and white looks good" the same day, the 16mm Cinema is approved, both Film Stocks. | ADR 0016, DEC-04, CAM-07, CAM-17, QA-16 |
| What the 6×6 Medium Format's color Film Stock develops with, after he replied on its board with a written spec and then sent the files that define the look | Captain, 2026-10-12: "please apply attached files to immerse 6x6 portra 400 film". The color Film Stock's look is his generator's "scan" look, read from the table that generator wrote, with the way in his spec gives a photograph and its passes, a mild lens vignette and very fine grain, in place of the look tuned on the board. Its blacks are lifted to about 7.5 percent and its whites sit a little under ADR 0013's limit, so it is taken from his files and not held to the rule. The vignette is not in PRD section 6.1's row. Shown it on the board beside the same with stronger greens, he wrote "everything looks good" on 2026-10-12, taken as his approval of the 6×6 Medium Format as it is in the app, both Film Stocks; the stronger greens stay out. | ADR 0016, DEC-04, CAM-05, CAM-17, QA-16 |
| Whether anything his 6×6 spec describes beyond the look is built: capture in ProRAW with the phone's own sharpening and noise reduction switched off, a 10-bit output format, and the items the spec leaves open (calibrating against real scans, a reference scanner, how warm and bright the finish is) | Captain, 2026-10-12: "Immerse 6x6 spec beyond the look: keep it as the look only". Nothing beyond the look is built: capture and the developed master's format stay as they are. | DEC-04, CAM-05, CAM-17 |
| The remaining open v1 decisions, put to him in six lettered parts, each with a recommendation (A looks and export, B sample photos and music, C Darkroom limits, D speed and storage targets, E support and App Store wording, F learning without analytics); the parts as he read them are quoted in the 2026-10-13 addendum to the [open-decision recommendations](2026-09-29-film-camera-experience-v1-open-decision-recommendations.md) | Captain, 2026-10-13: "looks good. can we change the exposure, dodge and burn to plus and minus 3 stops?" Every recommendation stands as it was put to him, with that one change. The rows below record each part; A.1 (the Instant's contrast and print-to-print variation) and A.3 (the toning strength) go to review boards of their own. | DEC-04, DEC-05, DEC-11, DEC-12, DEC-13, DEC-14 |
| C. Darkroom limits, recommended as print exposure of plus or minus 2 stops, color filtration of plus or minus 30, Dodge and Burn of plus or minus 1 stop, crop per photo with the 6×6 staying square, Reset to the exact original, the Instant asking about the original after each print, and a soundtrack changeable later without developing again | Captain, 2026-10-13: approved, with print exposure and Dodge and Burn each changed to plus and minus 3 stops. In the app the exposure slider runs from -3.0 to +3.0 in tenths, a Dodge or Burn stroke has a strength of 0.1 to 3.0 stops, and overlapping strokes together stop at 3 stops. A recipe saved under the earlier limits prints the same; a stored value outside the limits is refused, not clamped. | DEC-11, DRK-01 to DRK-06, DRK-09, DRK-10, DEV-05, MOV-09 |
| A.2. Export sizes and format, recommended as JPEG photos with the Disposable up to 12 megapixels and the 6×6 at 3072 × 3072, and Movies as H.264 at 1920 × 1440, the Super 8 at 18 frames a second and the 16mm at 24, silent, with the Instant's size open | Captain, 2026-10-13: approved. A portrait Movie is 1440 × 1920 (PRD FR-05). | DEC-04, CAM-02, CAM-05, MOV-11 |
| The Instant's export size, with the white card part of the print, put to him as A (the print as developed, 2282 × 2774), B (enlarged on export) or C (new prints developed larger), with a rendered example; and whether Movies, which carry no color tags, should be tagged (`Evidence/NativeApp/darkroom-export-decisions-060/instant-export-size-proposal.md`) | Captain, 2026-10-13: "instant export size: A,  leave Movies as they are". An Instant print is saved to Photos exactly as it was developed, with no resampling. No color tags are added to Movies, by his decision. A newly developed clip is now its whole frames, with the last one held to where the recording stopped, which is what makes the 18 and 24 frames a second he approved true of the file; a clip developed before this is not developed again. Photos stay sRGB. Whether tagging would change anything on a phone is to be looked at during the manual iPhone test. | DEC-04, CAM-03, MOV-11 |
| B. Sample photos and music, recommended as only material he owns or has written rights to, no built-in soundtrack until a license allows it inside exported Movies, and his own shots as the samples, one for each Camera and Film Stock | Captain, 2026-10-13: approved. The shipped catalog stays empty until he supplies the shots. | DEC-05, CAM-10, MOV-09 |
| D. Speed and storage targets, recommended as the iPhone 11 as the oldest phone, a photo saved in under 1 second, a 27-photo roll developed in under 45 seconds, a full Super 8 Movie assembled in under 90 seconds and a warning below 2 GB free, approved as targets and measured when a phone turns up, with his iPhone 13 Pro as the oldest supported phone as the alternative | Captain, 2026-10-13: approved as targets. None is measured, because no iPhone 11 is available. The iPhone 11 stays the oldest supported phone. The warning below 2 GB free is built as CAP-15 (row below). | DEC-12, ARC-08, CAP-15, QA-13 |
| E. Support and App Store wording, recommended as approving the approach now (no server, account, analytics or microphone; exports stay and old backups can bring media back; no promise of recovery without a backup) and drafting the wording closer to launch | Captain, 2026-10-13: approved. The wording is still to be written. | DEC-13, QA-14 |
| F. Learning without analytics, recommended as no analytics in the app, with TestFlight interviews, tester feedback and Apple's own reports | Captain, 2026-10-13: approved. | DEC-14 |
| Where the warning below 2 GB free appears, its words, and whether it stops anything, which part D did not say; shown the warning as built, with screenshots: above Load Film, and on the Film screen above Open Camera while the Film is open and above Develop Film once it is complete; two sentences, one before captures and one before Development; warn only, with nothing to dismiss | Captain, 2026-10-13: "low storage - approve". Built as shown. He was also told that saving to Photos has no warning and one there would be a follow-up, and asked for none. 2 GB is 2,000,000,000 bytes, as iPhone Settings counts it (`Evidence/NativeApp/low-storage-warning-062.md`). | DEC-12, CAP-15, QA-13 |
| The Instant's contrast, left provisional when he approved its faded look, asked on its look review board after the study of preserved 1970s prints, which showed the contrast as it was (A) beside the contrast the study supports (B) | Captain, 2026-10-13: "B". The Instant keeps its faded color, softness, texture and card and takes the study's contrast: black a little deeper and a print's S-shaped curve in place of one held flat through the middle tones. It is treatment version 4; an Instant Film loaded under version 3 keeps the earlier contrast. | DEC-04, CAM-03, CAM-12, CAM-17, QA-16, ADR 0016, ADR collection |
| The size of the Instant's print-to-print variation, shown on the same board as a pack of ten prints with the variation as it was and with the wider variation the study supports, and asked of him again because "B" named the contrast | Captain, 2026-10-13: B means "contrast only". The print-to-print variation is unchanged. | DEC-04, CAM-03, QA-16, ADR 0016 |
| Whether to reword the Instant's Load Film line, "Warm, faded color, soft contrast and soft detail", now that its contrast is higher than when the line was written | Captain, 2026-10-13: "leave it." The line is unchanged, and no product string changed. | CAM-15 |
| How strong each chemical toner goes at the top of its Darkroom slider and where the slider starts, asked on a comparison board of black-and-white 6×6 prints with sepia and selenium at 0.25 to 1.00 of the provisional range and selenium also at two, three and four times its top | Captain, 2026-10-13: "sepia - untoned to 1. selenium - untoned to 1". Both sliders start at the untoned print and top out at the strength shown as 1.00, the range the control already had. | DEC-04, DEC-11, DRK-03, DRK-10 |

The captain's words were "go with your recommendations on all four, adr 15 downloaded".

## Deferred to v2 — Group and Account tasks

> **Deferred to v2. None of these tasks is part of v1.**
> Captain decision, 2026-09-30: v1 ships personal Films only, and Groups for photos and video move to v2.
> Task IDs, text, dependencies and PRD references are kept exactly as in version 1.0 so v2 can pick them up without archaeology.
> Version 1.2 (2026-09-30) also moved the Account-only tasks here, marked "moved in 1.2", with their version 1.1 text, because v1 has no Account, sign-in, server or Account deletion (captain decision, ADR 0012).
> References to PRD FR-09 to FR-15 and FR-17 now point to PRD section 8 (Deferred to v2); other Group parts are in PRD sections 8.4 to 8.12, and the Account parts are in section 8.13.
> "v1" in preserved task text means the version 1.0 baseline that included Groups; read it as the first Group release.
> Like PRD section 16, this list is not implementation approval or a committed v2 roadmap.

### DEC — Open decisions (Group-only and Account-only tasks)

Dependency: resolve relevant choices before the affected implementation is accepted. See PRD section 15.

- [ ] DEC-06 — Decide long-term Group retention, abandoned sealed-Film policy, storage economics, and deletion/backup timing; do not invent automatic closing.
- [ ] DEC-07 — Resolve Trial eligibility enforcement after Account deletion and any necessary retention with explicit privacy rules. *(Account-only; moved in 1.2)*
- [ ] DEC-08 — Resolve lost Guest/device recovery, Account-link collisions, and account-free subscription-to-Account mapping for Group benefits.
- [ ] DEC-10 — Define unresolved reservation/Recording Turn recovery, authoritative chronology across devices, and missing-capture exclusion accounting.

### ARC — Foundation and architecture (Group-only tasks)

Dependency: relevant DEC items. PRD sections 11–13. Proposed engineering work, not a preselected vendor architecture.

- [ ] ARC-04 — Design authoritative Group APIs and atomic/idempotent membership, capacity, load, turn, closure, and Release operations.

### UX — Film Journal library and organization (Group-only tasks)

Dependency: ARC-01–ARC-03. PRD FR-02.

- [ ] UX-06 — Require Host-chosen Group title before Load/code; allow Host renaming without changing capture rules.
- [ ] UX-09 — Apply existing Group access and original-export deadlines to archived Films; never restore revoked/deleted content through restore.

### SET — New Film and Load Film (Group-only tasks)

Dependency: UX, CAM, entitlement interfaces. PRD FR-03.

- [ ] SET-02 — Show only Group-compatible Cameras; Instant must not be a selectable Group option.
- [ ] SET-07 — Use Host Load Film as Group Camera Lock; block codes/captures before completed configuration and entitlement checks.

### DEV — Completion and one-time Development (Group-only tasks)

Dependency: CAP, MOV where relevant, durable storage. PRD FR-06.

- [ ] DEV-09 — Apply Host-only Group development/recovery and route completion to Private Review, never auto-Release.

### DRK — Analog photo Darkroom (Group-only tasks)

Dependency: DEV, DEC-04/DEC-11, Group authorization for Private Prints. PRD FR-07.

- [ ] DRK-07 — Allow post-Release contributor-only Private Prints, keeping shared originals unchanged and exports permission-checked.

### IDN — Authentication and Guest ownership (Group-only and Account-only tasks)

Dependency: ARC-05, DEC-08. PRD FR-09/FR-20/FR-21.

- [ ] IDN-01 — Integrate Apple and Google Account authentication for Trial. *(Account-only; moved in 1.2)*
- [ ] IDN-02 — Create secure device-bound Guest Identity with display name and capture ownership without Account signup.
- [ ] IDN-03 — Implement optional Claim Guest Identity preserving contributions, membership, load history, and removal blocks.
- [ ] IDN-04 — Enforce Account prerequisites only where required; preserve account-free paid personal use. *(Account-only; moved in 1.2)*
- [ ] IDN-05 — Provide ownership-specific privacy access after leaving/removal without reopening general album access.

### GRP — Group setup, codes, joining, and fixed Host

Dependency: SET, IDN, ARC-04, BIL. PRD FR-09.

- [ ] GRP-01 — Create Host-named Group Film as the event itself; require active subscription and authenticated original Host.
- [ ] GRP-02 — Apply one locked Camera package to every Participant and prohibit per-Participant Camera changes.
- [ ] GRP-03 — Keep Host fixed; implement no co-host, transfer, successor, or automatic takeover path.
- [ ] GRP-04 — Enforce ten active people including Host and Guests, with concurrency-safe joining.
- [ ] GRP-05 — Generate short Join Code/QR only after Camera Lock and capacity configuration.
- [ ] GRP-06 — Show explicit Join Confirmation with title, Camera, Host review, visibility, and export rules before enrollment.
- [ ] GRP-07 — Admit eligible confirmed entrants without individual Host approval in the installed iOS app.
- [ ] GRP-08 — Support Host code revocation/replacement while open without removing existing Participants.
- [ ] GRP-09 — Invalidate codes on closure/Host deletion and require explicit new-code rejoining for every new Group.
- [ ] GRP-10 — Prevent access to Host's unrelated Films/settings; communicate fixed-Host and install-required limitations.

### POL — Shared Photo capacity and contributions

Dependency: GRP, BIL, authoritative accounting. PRD FR-10.

- [ ] POL-01 — Initialize exactly one full subscription-backed Host Load, without bonus free capacity.
- [ ] POL-02 — Enforce one full selected-Camera load per subscribed Account per Group, including Host.
- [ ] POL-03 — Enforce ten lifetime Photo loads independently from ten current members; never free consumed/contributed slots.
- [ ] POL-04 — Offer explicit Add 27/12 Shared Exposures to eligible authenticated subscribers at joining or later while open.
- [ ] POL-05 — Confirm exact amount, shared use, irreversibility, no extra charge, and expiration at closure before contribution.
- [ ] POL-06 — Never automatically add a load on joining, purchasing, or Guest claiming; declining preserves participation.
- [ ] POL-07 — Add the entire load to a first-come pool with visible remaining count; no personal quotas/reserves.
- [ ] POL-08 — Prevent retraction, repeat loads, Host reloads, transfers between Films, and capacity carryover.
- [ ] POL-09 — Enter Capacity Pause at zero; resume only on an eligible actual added load; no auto-close/develop.
- [ ] POL-10 — Explain new-Group capture when no load remains available and preserve load history through leave/removal/rejoin/expiry.

### SYN — Photo reservations and reliable uploads

Dependency: POL, CAP, ARC-04/ARC-06, DEC-10. PRD FR-11.

- [ ] SYN-01 — Require online atomic reservation before shared Photo capture; prevent last-exposure double allocation.
- [ ] SYN-02 — Consume reservation only after safe local save; return it for pre-save failure.
- [ ] SYN-03 — Preserve safely saved pending uploads through connection loss without refunding their exposure.
- [ ] SYN-04 — Retry uploads idempotently without duplicate captures/debits and honor privacy/exclusion tombstones.
- [ ] SYN-05 — Reconcile reservation/save/upload status after crashes or unavailable devices under the approved recovery policy.

### GMV — Movie Group duration and Recording Turns

Dependency: GRP, MOV, ARC-04, DEC-10. PRD FR-12.

- [ ] GMV-01 — Initialize one shared Camera Duration Pool without per-member allowances or subscriber-added time.
- [ ] GMV-02 — Require online exclusive Recording Turn acquisition; allow only one active recorder.
- [ ] GMV-03 — Show who is recording and block other recording until previous duration is confirmed.
- [ ] GMV-04 — Let an authorized active clip finish/save during lost connectivity within its reserved time budget.
- [ ] GMV-05 — Retry upload/duration confirmation without releasing a conflicting turn or double-debiting time.
- [ ] GMV-06 — Pause at exhausted duration without automatic close/develop; require another Group for additional recording.
- [ ] GMV-07 — Integrate interruption and unresolved-turn recovery while retaining eligible clips and strict capacity limits.

### CLS — Irreversible Group closure

Dependency: GRP, SYN/GMV. PRD FR-13.

- [ ] CLS-01 — Provide Host-only manual Close Group Film with no automatic Closing Time/deadline.
- [ ] CLS-02 — Warn exact unused exposures/time before irreversible waste and closure.
- [ ] CLS-03 — Atomically stop new joins/reservations/turns, invalidate codes, and prevent reopening.
- [ ] CLS-04 — Retain eligible safely saved pre-close Photo captures with pending uploads.
- [ ] CLS-05 — Permit an existing Movie turn to finish within prior authorization; waste its unused time when it ends.
- [ ] CLS-06 — Block Development until eligible uploads and active-turn duration resolve; never auto-develop on closure.
- [ ] CLS-07 — After 48 hours from closure, offer Host-confirmed Develop Without Missing Captures with identified permanent exclusions; reject later insertion.

### REL — Development, Private Review, Release, and access

Dependency: CLS, DEV, ARC-06, privacy interfaces. PRD FR-14.

- [ ] REL-01 — Enforce Host-only explicit development of completed Group Films and Host-only resumable progress.
- [ ] REL-02 — Make developed Group media Private Review-only until explicit Host Release.
- [ ] REL-03 — Allow Host safety Discard during Private Review and after Release without edit/reorder rights over others.
- [ ] REL-04 — Let Host select silence/one built-in soundtrack for silent Group Movies during review and permanently lock at Release.
- [ ] REL-05 — Keep released playback/exports/reassembled Movies consistent with the locked soundtrack and orientation.
- [ ] REL-06 — Enforce online current-access and withdrawal checks for every Group viewing/export path, including cached media.
- [ ] REL-07 — Display Contributor Attribution in details/metadata only, never burned into image/video output.
- [ ] REL-08 — Verify no exhaustion, closure, Development, stale notification, or lost Host login independently releases media.

### EXP — Group exports and original-source window

Dependency: REL, STO, PRV. PRD FR-15.

- [ ] EXP-01 — Let current members export any visible developed Group photo or the complete Movie after Release.
- [ ] EXP-02 — Keep Private Print exports contributor-only and shared developed originals unchanged.
- [ ] EXP-03 — Limit Group original-source exports to the authenticated contributor's own captures.
- [ ] EXP-04 — Present the original-export choice/deadline at Release or first return; anchor expiry to Release, not first visit.
- [ ] EXP-05 — Implement source cleanup after successful chosen export or explicit decline with verified master/notice, plus seven-day cleanup of remaining sources including failed/unattempted exports at expiry.
- [ ] EXP-06 — Explain original deadline, unrecoverability, and independent non-revocable external exports before relevant actions.
- [ ] EXP-07 — Recheck access/withdrawal immediately before serving exports and exclude blocked/removed/stale Movie versions.
- [ ] EXP-08 — Preserve masters, Developed Clips, and reversible edits after source expiry; report Photos permission/write failures accurately.

### NTF — Optional Release Notification

Dependency: REL, current identity/membership checks. PRD FR-15.

- [ ] NTF-01 — Offer optional notifications without gating join/capture/view access.
- [ ] NTF-02 — Send only after Host Release to eligible current members; no capture reminders, shot activity, or Private Review alerts.
- [ ] NTF-03 — Use text-only Film title plus “Your Film is ready,” with no media attachments or previews.
- [ ] NTF-04 — Recheck current online permissions on notification open; old alerts cannot restore revoked access.

### PRV — Capture privacy and moderation (Group-only tasks)

Dependency: ownership/access design, media deletion/reassembly architecture. PRD FR-16.

- [ ] PRV-02 — Implement permanent contributor Withdraw of own revealed Group photos/clips for everyone.
- [ ] PRV-03 — Implement bulk Withdraw Unreleased Captures for all own saved contributions without preview/selective removal/Host approval.
- [ ] PRV-04 — Preserve withdrawal access while open, closed, in Private Review, and after leaving/removal as appropriate.
- [ ] PRV-09 — Add Report Capture for released visible content to request Host moderation without automatic deletion.

### MEM — Leaving and removing Participants

Dependency: GRP, IDN, PRV. PRD FR-17.

- [ ] MEM-01 — Implement non-Host Leave Film ending capture/general access and freeing the active-member slot.
- [ ] MEM-02 — Keep contributions, load history, pooled exposures, and withdrawal rights after leaving.
- [ ] MEM-03 — Allow same-identity voluntary rejoin only while open with valid code/free slot; grant no new load or restored media.
- [ ] MEM-04 — Implement Host Remove Participant while open with permanent known-identity rejoin block and no readmission action.
- [ ] MEM-05 — Preserve removal blocks through code changes and Guest claiming; preserve former contributor's privacy rights.
- [ ] MEM-06 — Communicate known-identity—not guaranteed person-level—blocking and distinguish leave/remove/archive/delete.

### IDD — Account/Guest deletion lifecycle (Group-only and Account-only tasks)

Dependency: IDN, PRV, BIL, TRI, ARC-06; relevant DEC-06/DEC-07 decisions. PRD FR-19.

- [ ] IDD-01 — Offer Delete Account with online submission and honest offline messaging. *(Account-only; moved in 1.2)*
- [ ] IDD-02 — Cover all own Group contributions, including claimed Guest captures, hosted/joined Films, and left/removed memberships.
- [ ] IDD-03 — On acceptance, immediately block covered sources/results/Private Prints/cached copies from viewing/export.
- [ ] IDD-04 — Block assembled Movies containing covered clips until privacy-safe reassembly; preserve other contributors' unchanged clips.
- [ ] IDD-05 — Keep Deletion Pending until permanent identity/data removal is confirmed; failures/sign-out are not completion. *(Account-only; moved in 1.2)*
- [ ] IDD-06 — Prohibit pending identities from joining, starting Group captures/turns, adding exposures, or claiming/linking to evade removal.
- [ ] IDD-07 — On Host deletion acceptance, disable hosted joins/captures and codes without deleting others' media or assigning a successor.
- [ ] IDD-08 — Keep others' unreleased media sealed, preserve their withdrawal rights, and retain authorized access to already released Films.
- [ ] IDD-09 — Remove identifying attribution from chronology placeholders and prevent delayed jobs/uploads from restoring deleted content.
- [ ] IDD-10 — Preserve eligible paid personal Films and captured Trials locally without deleted identity linkage, capacity reset, or automatic reveal. *(Account-only; moved in 1.2)*
- [ ] IDD-11 — Cancel zero-saved-capture Trial activation during Account deletion so it cannot persist as an account-free free-capture entitlement. *(Account-only; moved in 1.2)*
- [ ] IDD-12 — Warn subscribed users of continuing Apple billing and offer Manage Subscription without making cancellation/expiry a deletion prerequisite. *(Account-only; moved in 1.2)*

### BIL — All-inclusive subscription (Group-only tasks)

Dependency: DEC-02, ARC-05. PRD FR-20.

- [ ] BIL-04 — Validate active subscription for new Group hosting and optional subscriber load contributions with required Account identity.

### TRI — Account-scoped one-Film trial (Account-only tasks)

Dependency: IDN, ARC-05, CAP durability. PRD FR-21 (version 1.1 text in PRD section 8.13).

- [ ] TRI-05 — Implement original-device online Cancel Unused Trial only before first successful save. *(Account-only; moved in 1.2)*
- [ ] TRI-06 — Confirm old activation ends before releasing eligibility; reject capture from canceled activations and uncertain replacement trials. *(Account-only; moved in 1.2)*
- [ ] TRI-07 — Keep unresolved activation reserved while Account exists, with no automatic expiry/lost-device replacement. *(Account-only; moved in 1.2)*
- [ ] TRI-08 — Warn about original-device reservation and lack of automatic recovery before activation. *(Account-only; moved in 1.2)*
- [ ] TRI-10 — Implement Account-deletion exceptions for captured versus unused Trials and the approved post-deletion eligibility policy. *(Account-only; moved in 1.2)*

### QA — Cross-feature acceptance and launch readiness (Group-only and Account-only tasks)

Dependency: relevant implemented slices; test continuously rather than waiting until the end. PRD section 13.

- [ ] QA-05 — Verify Photo last-exposure races, duplicate contributions, member/load limits, leave/rejoin, and no refunds or load resets.
- [ ] QA-06 — Verify exclusive Movie turns, paused time, offline authorized completion, interruption, close races, and delayed duration confirmation.
- [ ] QA-07 — Verify closure/upload barriers, 48-hour explicit override, irreversible exclusion, and no automatic Development/Release.
- [ ] QA-08 — Verify Host/Guest/current/former/removed/deleting identity permissions across API, cache, thumbnails, notifications, and exports.
- [ ] QA-10 — Verify Account deletion pending/completion. *(Account-only; moved in 1.2)*

### Group clauses removed from v1 tasks

Each row shows the version 1.0 text of a task that keeps its ID in v1 with the Group clause removed. Restore the row text when the task is taken up for v2.

| Task | Version 1.0 text (verbatim) |
| --- | --- |
| DEC-03 | Choose minimum iOS/device support, native application stack, backend/media storage, authentication, and push providers. |
| DEC-09 | Define empty-Film closure/early Development and presentation when every Movie clip is removed. |
| DEC-13 | Define support/report escalation, privacy disclosures, and platform/launch review requirements beyond Host moderation. |
| ARC-02 | Design separate Film, capture, reveal, upload, membership, entitlement, archive, and deletion state models with enforceable invariants. |
| ARC-05 | Design identity/claim lineage, subscription validation, Trial reservation/consumption, and former-contributor rights. |
| ARC-06 | Design media authorization, private source/master/clip storage, privacy tombstones, deletion jobs, and stale-version retirement. |
| UX-02 | Make Start a Film primary and Join Film secondary; route Darkroom only from eligible developed photos. |
| UX-03 | Present unfinished, complete, developing, Private Review, and released states without sealed/inaccessible thumbnails. |
| UX-08 | Implement explicit per-user Archive, archived list, and restore without deletion, departure, or capacity changes. |
| SET-01 | Start with Personal/Group choice, default Personal, then Camera selection. |
| SET-04 | Ensure browsing/canceling previews consumes/reserves no Trial, creates no active Film, and grants no Group access. |
| SET-08 | Add Movie Orientation setup and lock at the agreed boundary; no per-Participant load/Camera configuration step. |
| CAP-04 | Support front/rear lenses across personal/Group Photo and Movie capture without replacing the selected Camera. |
| DEV-08 | Hide unfinished results and prevent recovery from restoring withdrawn/discarded/deleted content. |
| DRK-08 | Exclude Movie Darkroom, other-contributor edits, treatment swaps, AI/content manipulation, and saturation controls. |
| STO-04 | Offer optional Save Developed to Photos for eligible photographs, Private Prints, and complete Movies. |
| IDN-01 | Integrate Apple and Google Account authentication for Trial, hosting, and subscriber contributions. |
| IDN-04 | Enforce Account prerequisites only where required; preserve account-free Guest participation and paid personal use. |
| PRV-05 | Remove source/master/Developed Clip/Private Print/app-controlled cache content and retain metadata-only chronology. |
| PRV-06 | Enforce no refunds of exposures/time/loads/load slots and no Host undo or upload resurrection. |
| PRV-08 | Preserve surviving chronology, final orientation, and released soundtrack through reassembly; handle all-clips-removed policy once decided. |
| DEL-04 | Never restore used Trial eligibility or offer whole-Group deletion to Host/Participants. |
| IDD-01 | Offer Delete Account and account-free Delete Guest Identity with online submission and honest offline messaging. |
| IDD-05 | Keep Deletion Pending until permanent identity/data/media removal is confirmed; failures/sign-out are not completion. |
| BIL-02 | Permit unlimited new entitled personal/Group Films and all Cameras without per-Film charges or tiers. |
| BIL-05 | On expiry block only new Films/Groups/load contributions, retaining existing capture/completion/review/Release/edit/export rights. |
| TRI-09 | Preserve developed Trial access and reject entitlement refunds after used-Film deletion/Discard/abandonment; Groups do not consume Trial. |
| QA-04 | Verify every Darkroom control, per-exposure isolation, reset, own-only Private Prints, and exclusion of prohibited editing. |
| QA-09 | Verify source deletion, seven-day deadlines, failed Photos writes, verified-master gating, and unaffected external exports. |
| QA-10 | Verify revealed/bulk withdrawal, identity deletion pending/completion, claimed ownership cleanup, and no upload resurrection. |
| QA-12 | Verify subscription expiration, account-free paid use, multi-device Trial contention, cancellation uncertainty, and preserved personal Films after identity deletion. |

Group names and dependencies changed in v1: MOV was "Personal/shared Movie mechanics"; IDN was "Authentication and Guest ownership" with dependency "ARC-05, DEC-08" and "PRD FR-09/FR-20/FR-21"; PRV was "Capture privacy and moderation" with dependency "ownership/access design, media deletion/reassembly architecture"; IDD was "Account/Guest deletion lifecycle" with dependency "IDN, PRV, BIL, TRI, ARC-06; relevant DEC-06/DEC-07 decisions"; DRK dependency included "Group authorization for Private Prints".

### Account, server and analytics clauses changed in v1 tasks (version 1.2)

Each row shows the version 1.1 text of a task that keeps its ID in v1 with its text rewritten for the per-iPhone Trial, the on-phone scope, iOS 26 iPhone-only, device backup, no analytics, and deferred pricing. Restore the row text when the task is taken up for v2 Accounts.

| Task | Version 1.1 text (verbatim) |
| --- | --- |
| DEC-02 | Set monthly/yearly pricing and specify purchase restoration, offers, refunds/revocations, and entitlement edge handling without changing existing-Film access promises. |
| DEC-03 | Choose minimum iOS/device support, native application stack, backend, and authentication providers. |
| DEC-14 | Approve success metrics/targets and decide whether to add privacy-respecting analytics; no implicit media telemetry. |
| ARC-01 | Establish native application build, local development setup, supported devices, and test environments. |
| ARC-03 | Design local media persistence, atomic save/recovery boundaries, Camera versioning, and developed-master integrity checks. |
| ARC-05 | Design identity, subscription validation, and Trial reservation/consumption. |
| SET-03 | Permit curated Camera Preview before sign-in/activation with no live filter feed or user capture access. |
| SET-04 | Ensure browsing/canceling previews consumes/reserves no Trial and creates no active Film. |
| CAP-08 | Support entitled personal offline capture; enforce prior online Trial Activation where applicable. |
| STO-02 | Explain local-only storage/device-loss risk and that Account sign-in does not create Film backup/sync. |
| PRV-10 | Explain permanent app removal and external-copy limitations; verify no stale viewing/export after accepted privacy action. |
| DEL-03 | For unused activated Trial Films, require confirmed original-device online cancellation before deleting; retain Film on uncertainty. |
| BIL-03 | Support purchase and paid personal use without a separate app Account. |
| BIL-06 | Implement purchase restoration, renewal, entitlement reconciliation, and approved refund/revocation behavior. |
| BIL-07 | Provide subscription-management entry and clear distinction between billing cancellation, identity deletion, and Film deletion. |
| TRI-01 | Offer exactly one full personal Photo OR Movie Trial Film with any Camera after required Account sign-in. |
| TRI-02 | Reserve eligibility online for one Film on one original device across devices/reinstalls. |
| TRI-04 | Support offline capture after activation and reconcile first-save consumption without permitting another Trial. |
| TRI-09 | Preserve developed Trial access and reject entitlement refunds after used-Film deletion/Discard/abandonment. |
| QA-12 | Verify subscription expiration, account-free paid use, multi-device Trial contention, cancellation uncertainty, and preserved personal Films after Account deletion. |
| QA-13 | Verify supported devices, accessibility, front mirroring/output orientation, mic/camera/Photos denial, low storage, relaunch, export fidelity, and agreed performance budgets. |

Group names and dependencies changed in v1.2: TRI was "Account-scoped one-Film trial" with dependency "IDN, ARC-05, CAP durability"; BIL had dependency "DEC-02, ARC-05"; IDN and IDD have no v1 tasks (IDN was "Authentication" with dependency "ARC-05", IDD was "Account deletion lifecycle" with dependency "IDN, BIL, TRI; relevant DEC-07 decision"). New IDs added in v1.2: DEC-15, DEC-16, DEC-17, STO-11, TRI-11 and QA-15.

### Camera look, Film Stock and Darkroom clauses changed in v1 tasks (version 2.0)

Each row shows the version 1.5 text of a v1 task that keeps its ID with its text rewritten for PRD version 2.0 and the captain's 2026-10-06 decisions. These rows are history; the tasks above are current.

| Task | Version 1.5 text (verbatim) |
| --- | --- |
| CAM-05 | Implement 1960s 6×6 Medium Format: 12 square exposures, waist-level presentation, deliberate focus/exposure. |
| CAM-06 | Implement 1960s Super 8 Home Movie: 200-second fixed capacity, pronounced grain/flicker, silent capture. |
| CAM-07 | Implement 1960s 16mm Cinema: 165-second fixed capacity, finer grain/cinematic character, silent capture. |
| CAM-10 | Create curated sample media and plain-language capacity/control/reveal/audio descriptions for every Camera. |
| CAM-11 | Use descriptive historical-format names; exclude digital formats, separate stock selection, and unapproved manufacturer branding. |
| CAM-12 | Validate format-distinct developed treatments and bounded authentic imperfections without synthetic catastrophic capture destruction. |
| SET-05 | Add explicit Load Film confirmation showing Camera, capacity, and Reveal Rule. |
| SET-06 | Lock Camera package permanently at Load while preserving adjustable supported focus/flash/exposure controls. |
| CAP-03 | Render Camera-authentic framing/capture cues without developed grain, color, leaks, scratches, or tape-damage preview. |
| DRK-02 | Implement print exposure and medium-appropriate contrast/contrast-grade controls. |
| DRK-03 | Implement eligible color filtration/balance and medium-appropriate chemical toning without saturation. |
| DRK-04 | Implement agreed analog-print crop behavior without changing the underlying Camera package. |
| DEC-04 | Approve each Camera's rendering, output resolution/codec/frame-rate/audio specifications and medium-specific controls. |
| DEC-11 | Specify analog Darkroom ranges/crop boundaries, Instant original-export choice timing, and personal soundtrack reselection behavior. |

The two DEC rows are unchanged in their first sentence; version 2.0 appended the decided parts, so their earlier text is the sentence shown.

### Contrast wording superseded on 2026-10-07 (version 2.1)

The captain's 2026-10-07 decision restored contrast grades on color Films.
These rows are the 2026-10-06 wording, kept as history; the tasks above are current.

| Task | 2026-10-06 text (verbatim) |
| --- | --- |
| DEC-11 | Specify analog Darkroom ranges/crop boundaries, Instant original-export choice timing, and personal soundtrack reselection behavior. Partly decided (PRD version 2.0 and the captain, 2026-10-06): Instant prints have no crop; color Films get no contrast control; contrast grades and chemical toning apply only to black-and-white Films, which in v1 are 6×6 Medium Format Films on the black-and-white Film Stock (the captain's answer to how PRD FR-07's "appropriate contrast/contrast grades" applies; the PRD's own text is unchanged). Still open: control ranges, Instant original-export timing, soundtrack reselection. |
| DRK-02 | Implement print exposure and, for black-and-white Films only, contrast grades; color Films have no contrast control (captain decision 2026-10-06). |
| DRK-03 | Implement eligible color filtration/balance and, for black-and-white Films only, chemical toning, without saturation. |
| DRK-10 | (PRD 2.0 slice 1) Remove the contrast control from color Films and offer contrast grades and chemical toning only on black-and-white Films, which in v1 are 6×6 Medium Format Films on the black-and-white Film Stock (captain decision 2026-10-06). |
| Slice 1 row | / 1 / Names and capacity, the Instant card and no crop, contrast removal on color Films, catalog copy / CAM-13, CAM-14, DRK-09, DRK-10, CAM-15 / |

## Milestone tracking

Milestones are dependency groupings, not additional task counts or committed launch dates.

| Milestone | Main task groups | Exit evidence |
| --- | --- | --- |
| M0 — Prerequisites | DEC, ARC, TRI-11 | Approved scope-sensitive choices, implementation architecture, and the iOS 26 Keychain device check |
| M1 — Personal photo slice | UX, CAM, SET, CAP, DEV, STO | Real capture through reveal/export, durable and private |
| M2 — Complete personal experience | MOV, DRK, DEL, BIL, TRI | All personal formats and entitlement/lifecycle acceptance; price decided (DEC-02) before billing work starts |
| M3 — Shared photos (deferred to v2) | Group-only tasks under Deferred to v2: IDN-02, IDN-03, IDN-05, GRP, POL, SYN, CLS, REL, EXP | Concurrent real devices; sealed capture through Host Release |
| M4 — Personal privacy lifecycle | PRV (v1 tasks); GMV, MEM, the Group tasks of PRV, and all IDD tasks are deferred to v2 | Tested personal Discard/Movie reassembly |
| M5 — Release readiness | QA, outstanding DEC (NTF and the Group and Account QA tasks deferred to v2) | Native, billing, privacy, media-quality evidence |

The version 2.0 tasks follow the slice order in "PRD 2.0 implementation slices": slices 1 and 2 belong to M1 and M2 as the Cameras they touch do, and slices 3 and 4 to M2. The manual iPhone test candidate is the build that includes PRD 2.0.

The early checks ARC-08 to ARC-12 belong to the milestones named in their task text (M1 and M2, with the backup drill repeated in M5) even though their IDs are in the ARC group.

Privacy architecture is required before implementation, not deferred until M4; shared-slice prerequisites belong to v2, as do the Account-only tasks (IDN-01, IDN-04, IDD, TRI-05 to TRI-08, TRI-10, DEC-07, QA-10). No checked discovery item means these milestones have passed.

## Change log

| Date | Change |
| --- | --- |
| 2026-09-29 | Created local v1 baseline from the recorded discussion, domain model, ADRs, and selected Film Journal prototype. |
| 2026-09-30 | Version 1.1: captain decision to ship personal Films only. Group-only tasks (94) moved to the Deferred to v2 section with IDs unchanged; mixed tasks keep their IDs with Group clauses removed; no IDs added or removed. |
| 2026-09-30 | Version 1.2: captain decisions recorded in the PRD's version 1.2 notes and FR-21. Account-only tasks moved to Deferred to v2 with IDs unchanged; earlier task wording is preserved in the tables above. Added DEC-15, DEC-16, DEC-17, STO-11, TRI-11 and QA-15; DEC-15 to DEC-17 were decided the same day. |
| 2026-09-30 | Version 1.3: the captain approved the v1 architecture pack, revision 3. Added the [architecture baseline](2026-09-29-film-camera-experience-v1-architecture.md) document and five early-check tasks, ARC-08 to ARC-12; no existing ID, status or decision changed. |
| 2026-09-30 | Version 1.4: added the PRD's Users (1.1) and User journeys (5.1) sections and recorded the approved v1 clickable prototype in PRD section 18, as a design reference only with its questions pending. No task ID, task count, status or decision changed. |
| 2026-09-30 | Version 1.5: recorded the captain's DEC-09 empty-Film decision and added the evidence map. No task ID changed. |
| 2026-10-06 | Version 2.0: PRD version 2.0 (ADRs 0013 to 0015) landed beside PRD 1.5. Added fourteen tasks (CAM-13 to CAM-17, SET-09, CAP-11 to CAP-14, DEV-11, DRK-09, DRK-10, QA-16) in the order of the new implementation slices section, rewrote the text of twelve existing tasks with the version 1.5 wording preserved at the end of the Deferred to v2 section, and noted the decided parts of DEC-04 and DEC-11. Recorded the captain's four 2026-10-06 decisions. No ID was renumbered and no task status changed. |
| 2026-10-07 | Version 2.1: PRD version 2.1 (same file) amends FR-07 at the captain's request: Darkroom contrast grades 0 to 5 apply to every Photo Film, color and Instant included; chemical toning stays black-and-white only. Reworded DEC-11, DRK-02, DRK-03, DRK-10 and the slice 1 row and added the captain's decision to the decisions table, with the 2026-10-06 wording kept as history. No ID, task count or status changed. |
| 2026-10-10 | PRD 2.0 slice 4 (CAM-17, QA-16): the captain reviewed each Camera's look on side-by-side boards. He chose the faded look for the 1970s Instant ("faded") and a muted look with a glow for the 1960s Super 8 Home Movie ("muted with a glow"), recorded as ADR 0016, exceptions to ADR 0013, with reconciliation notes in the ADR collection and rows in the Captain decisions table, and with the text of ADR 0013 and of PRD sections 6.1 and 6.2 left as the captain wrote it; he kept the 1990s Disposable fresh ("fresh"). Added notes to CAM-12 and CAM-17 and updated DEC-04. No task ID, task count or checkbox changed. |
| 2026-10-12 | PRD 2.0 slice 4 (CAM-17, QA-16): the captain sent the files that define the 16mm Cinema's color look ("please apply the attached for immerse - 16mm camera kodak vision3 250d"). They are applied as that Film Stock's Developed Treatment, in place of the values tuned on its board, with the black kept at 4 percent at his word the same day ("please bring the black up to 4 percent", then "lets go with C" for the way that opens the shadows as well), and recorded in ADR 0016 with a row in the Captain decisions table and notes on DEC-04, CAM-12 and CAM-17. The same day he sent the files for the 6×6 Medium Format's color look ("please apply attached files to immerse 6x6 portra 400 film"), applied as that Film Stock's Developed Treatment and recorded the same way. He approved both Cameras on their boards the same day, so every Camera's look now has his approval; DEC-04's note says what stays open. No task ID, task count or checkbox changed. |
| 2026-10-13 | The captain answered the remaining open v1 decisions ("looks good. can we change the exposure, dodge and burn to plus and minus 3 stops?"). Recorded in the 2026-10-13 addendum to the open-decision recommendations, in PRD sections 15 and 17 and in eight rows of the Captain decisions table, the eighth for his second answer that day ("instant export size: A,  leave Movies as they are"). DEC-11 is decided and checked. DEC-04 (export sizes and formats), DEC-05, DEC-12, DEC-13 and DEC-14 carry what he decided and what stays open, and stay unchecked. The app carries the Darkroom limits, the Instant's question about each print's original and the soundtrack rule, and tests read the approved export sizes and formats from exported files (`Evidence/NativeApp/darkroom-export-decisions-060.md`). Added one task, CAP-15, unchecked, for the warning below 2 GB free, which he approved as a target and which is not built; the tracker now contains 253 items. No existing ID changed; one checkbox changed. |
| 2026-10-13 | The Instant's contrast and variation and the toning range (DEC-04, QA-16), the two parts of the day's answers that went to review boards of their own: a study of 37 preserved 1970s prints went before the captain on the Instant's board with the contrast it supports, and he chose that contrast ("B"); it is treatment version 4, with version 3 kept renderable for Instant Films loaded under it, and ADR 0016 records it; its print-to-print variation stays as it was ("contrast only"). On a comparison board of toned black-and-white 6×6 prints he set both toners' sliders from the untoned print to the strength shown as 1.00 ("sepia - untoned to 1. selenium - untoned to 1"). Asked whether the Instant's Load Film line should be reworded, he said "leave it." Added a note to DEC-04, where both were the last items open, and to DEC-11, and four rows to the Captain decisions table. No task ID, task count or checkbox changed. |
| 2026-10-14 | CAP-15, the warning below 2 GB free, is built: the captain approved where it appears, its two sentences and warn only on 2026-10-13 ("low storage - approve"), recorded in the Captain decisions table and in the 2026-10-13 addendum to the open-decision recommendations. CAP-15 and DEC-12 now say it is built, and CAP-15 stays unchecked until a nearly full iPhone runs it (`Evidence/NativeApp/low-storage-warning-062.md`). No task ID, task count or checkbox changed. |
